const mongoose = require('mongoose');
const Product = require('./models/product');


mongoose.connect('mongodb://localhost:27017/shopping-app')
    .then(() => console.log('DB Connected'))
    .catch((err) => console.log(err));


const products = [
     {
        name: 'Iphone 14 pro',
        img: 'https://unsplash.com/photos/3tqzbtSRRqA',
        price: 150000,
        desc: "iPhone 14 Pro and iPhone 14 Pro Max are splash, water and dust resistant, and were tested under controlled laboratory conditions with a rating of IP68 under IEC standard 60529 (maximum depth of 6 metres up to 30 minutes). Splash, water and dust resistance are not permanent conditions. Resistance might decrease as a result of normal wear"
    },
    {
        name: '  Air Jordan Shoes',
        img: 'https://unsplash.com/photos/aDZ5YIuedQg',
        price: 150000,
        desc: "Air Jordan is a line of basketball shoes and athletic apparel produced by American corporation Nike, Inc. The first Air Jordan shoe was produced for Hall of Fame former basketball player Michael Jordan during his time with the Chicago Bulls in late 1984 and released to the public on April 1, 1985."
    },
    {
        name: 'Titan Watch',
        img: 'https://unsplash.com/photos/12V36G17IbQ',
        price: 18000,
        desc: "A watch is a portable timepiece intended to be carried or worn by a person. It is designed to keep a consistent movement despite the motions caused by the person's activities"
    },
    {
        name: 'Macbook Pro+',
        img: 'https://images.unsplash.com/photo-1611186871348-b1ce696e52c9?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=870&q=80',
        price: 250000,
        desc: "Apple MacBook Pro is a macOS laptop with a 13.30-inch display that has a resolution of 2560x1600 pixels. It is powered by a Core i5 processor and it comes with 12GB of RAM. The Apple MacBook Pro packs 512GB of SSD storage"
    },
    {
        name: 'Drones',
        img: 'https://unsplash.com/photos/u1EGfuB4llU',
        price: 180000,
        desc: "An unmanned aerial vehicle (UAV), commonly known as a drone, is an aircraft without any human pilot, crew, or passengers on board"
    },
    ,
    {
        name: 'Bicycle',
        img: 'https://m.media-amazon.com/images/I/41ie-EXn4pL.jpg',
        price: 1960,
        desc: "The iPhone is a line of smartphones designed and marketed by Apple Inc."
    },
    {
        name: 'Nokia 110',
        img: 'https://m.media-amazon.com/images/I/51mpTklF2lL._SL1500_.jpg',
        price: 1350,
        desc: "The Nokia 110 Dual SIM phone comes with a 1.77 inch display for clear and vibrant visual experience on your phone. The phone is black in colour and has a compact size. It comes with a dual SIM card setup. The phone also comes with basic mobile phone features such as alarm, ultra-torch light etc"
    },

];



async function seedDB(){
    await Product.deleteMany({});
    await Product.insertMany(products);
    console.log('Product Seeded');
}

seedDB();



